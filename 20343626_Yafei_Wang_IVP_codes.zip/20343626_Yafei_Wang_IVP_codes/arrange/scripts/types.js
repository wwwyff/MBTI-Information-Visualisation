var a =0;
Types();
function Types(){
d3.csv('data/types.csv')
      .then(function(data){
          console.log(data);
          $("#TypeNickname").text(data[a].Type+"("+data[a].Nickname+")");
          $("#Introduction").text(data[a].Introduction);
          $("#Definition").text(data[a].Definition);
          $("#Celebrities").text(data[a].Celebrities);
      });
    }
    function INTJ(){
        a = 0;
        Types();
    }
    
    function INTP(){
        a = 1;
        Types();
    } 
    function ENTJ(){
        a = 2;
        Types();
    }
    function ENTP(){
        a = 3;
        Types();
    }
    
    function INFJ(){
        a = 4;
        Types();
    }
    
    function INFP(){
        a = 5;
        Types();
    }
    
    function ENFJ(){
        a = 6;
        Types();
    }
    function ENFP(){
        a = 7;
        Types();
    }
    
    function ISTJ(){
        a = 8;
        Types();
    }
    
    function ISFJ(){
        a = 9;
        Types();
    }
    function ESTJ(){
        a = 10;
        Types();
    }
    
    function ESFJ(){
        a = 11;
        Types();
    }
    function ISTP(){
        a = 12;
        Types();
    }
    
    function ISFP(){
        a = 13;
        Types();
    }
    
    function ESTP(){
        a = 14;
        Types();
    }
    function ESFP(){
        a = 15;
        Types();
    }