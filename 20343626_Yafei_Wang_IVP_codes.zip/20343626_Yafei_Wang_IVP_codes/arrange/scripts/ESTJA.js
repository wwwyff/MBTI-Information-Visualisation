//import a from './a.js'
//import b from './b.js'

const svg = d3.select('#countryestjasvg');
const width = +svg.attr('width');
const height = +svg.attr('height');
const margin = {top: 20, right: 20, bottom: 20, left: 100};
const innerWidth = width - margin.left - margin.right;
const innerHeight = height - margin.top - margin.bottom;
const xValue = (datum) => {return datum.obj;}
const yValue = (datum) => {return datum.Country};
var x = 1;
var title ='ESTJ-A';


const render = function(data){

  data = data.sort(function (a,b) {return d3.ascending(a.value, b.value); });
  // Linear Scale: Data Space -> Screen Space; 
  const xScale = d3.scaleLinear()
  .domain([0, d3.max(data, xValue)])
  .range([0, innerWidth]);

  // Introducing y-Scale; 
  const yScale = d3.scaleBand()
  .domain(data.map(yValue))
  .range([0, innerHeight])
  .padding(0.1);

  
  const g = svg.append('g')
  .attr('transform', `translate(${margin.left}, ${margin.top})`);

  // Do the data join (Enter)
  g.selectAll('rect')
  .data(data)
  .enter() 
  .append('rect')
  .attr('y', datum => yScale(yValue(datum)))
  .attr('width', (datum) => {return xScale(xValue(datum))}) 
  .attr('height', yScale.bandwidth())
  .attr('fill', 'steelblue')

  // Adding axes
  g.append('g').call(d3.axisLeft(yScale));
  g.append('g').call(d3.axisBottom(xScale))
  .attr('transform', `translate(${0}, ${innerHeight})`);

  g.append('text')
        .text(title)
        .attr('y', 0)
        .attr('x', innerWidth / 2 - 10);
}
shiftdata();

function shiftdata(){
d3.csv('data/countries.csv')
.then(function(data){
  
    data.forEach( datum => {
      switch(x){
        case 0: datum.obj = datum.obj;
        case 1: datum.obj = datum.ESTJA,title ='ESTJ-A'
        break;
        case 2: datum.obj = datum.ESFJA,title ='ESFJ-A'
        break;
        case 3: datum.obj = datum.INFPT,title ='INFP-T'
        break;
        case 4: datum.obj = datum.ESFJT,title ='ESFJ-T'
        break;
        case 5: datum.obj = datum.ENFPT,title ='ENFP-T'
        break;
        case 6: datum.obj = datum.ENFPA,title ='ENFP-A'
        break;
        case 7: datum.obj = datum.ESTJT,title ='ESTJ-T'
        break;
        case 8: datum.obj = datum.ISFJT,title ='ISFJ-T'
        break;
        case 9: datum.obj = datum.ENFJA,title ='ENFJ-A'
        break;
        case 10: datum .obj = datum.ESTPA,title ='ESTP-A'
        break;
        case 11: datum.obj = datum.ISTJA,title ='ISTJ-A'
        break;
        case 12: datum.obj = datum.INTPT,title ='INTP-T'
        break;
        case 13: datum.obj = datum.INFJT,title ='INFJ-T'
        break;
        case 14: datum.obj = datum.ISFPT,title ='ISFP-T'
        break;
        case 15: datum.obj = datum.ENTJA,title ='ENTJ-A'
        break;
        case 16: datum.obj = datum.ESTPT,title ='ESTP-T'
        break;
        case 17: datum.obj = datum.ISTJT,title ='ISTJ-T'
        break;
        case 18: datum.obj = datum.ESFPT,title ='ESFP-T'
        break;
        case 19: datum.obj = datum.ENTPA,title ='ENTP-A'
        break;
        case 20:datum.obj = datum.ESFPA,title ='ESFP-A'
        break;
        case 21: datum.obj = datum.INTJT,title ='INTJ-T'
        break;
        case 22: datum.obj = datum.ISFJA,title ='ISFJ-A'
        break;
        case 23: datum.obj = datum.INTPA,title ='INTP-A'
        break;
        case 24: datum.obj = datum.ENTPT,title ='ENTP-T'
        break;
        case 25: datum.obj = datum.ISTPT,title ='ISTP-T'
        break;
        case 26: datum.obj = datum.ENTJT,title ='ENTJ-T'
        break;
        case 27: datum.obj = datum.ISTPA,title ='ISTP-A'
        break;
        case 28: datum.obj = datum.INFPA,title ='INFP-A'
        break;
        case 29: datum.obj = datum.ENFJT,title ='ENFJ-T'
        break;
        case 30:datum.obj = datum.INTJA,title ='INTJ-A'
        break;
        case 31: datum.obj = datum.ISFPA,title ='ISFP-A'
        break;
        case 32: datum.obj = datum.INFJA,title ='INFJ-A'
        break;
      }
        datum.obj = parseFloat(datum.obj);
      } )
   
    console.log(data)
    console.log(data.map( (datum) => {return datum.Country; } ))
    console.log(data.map( (datum) => {return datum.obj; } ))
    render(data);
    
});
}
function ESTJA() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=1;
  shiftdata();
}

function ESFJA() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=2;
  shiftdata();
}

function INFPT() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=3;
  shiftdata();
}

function ESFJT() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=4;
  shiftdata();
}
function ENFPT() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=5;
  shiftdata();
}
function ENFPA() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=6;
  shiftdata();
}

function ESTJT() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=7;
  shiftdata();
}

function ISFJT() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=8;
  shiftdata();
}

function ENFJA() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=9;
  shiftdata();
}
function ESTPA() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=10;
  shiftdata();
}

function ISTJA() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=11;
  shiftdata();
}

function INTPT() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=12;
  shiftdata();
}

function INFJT() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=13;
  shiftdata();
}

function ISFPT() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=14;
  shiftdata();
}

function ENTJA() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=15;
  shiftdata();
}

function ESTPT() {
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=16;
  shiftdata();
}
function ISTJT(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=17;
  shiftdata();
}

function ESFPT(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=18;
  shiftdata();
}

function ENTPA(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=19;
  shiftdata();
}

function ESFPA(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=20;
  shiftdata();
}

function INTJT(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=21;
  shiftdata();
}
function ISFJA(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=22;
  shiftdata();
}

function INTPA(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=23;
  shiftdata();
}

function ENTPT(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=24;
  shiftdata();
}

function ISTPT(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=25;
  shiftdata();
}

function ENTJT(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=26;
  shiftdata();
}

function ISTPA(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=27;
  shiftdata();
}

function INFPA(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=28;
  shiftdata();
}

function ENFJT(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=29;
  shiftdata();
}

function INTJA(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=30;
  shiftdata();
}

function ISFPA(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=31;
  shiftdata();
}

function INFJA(){
  d3.select('#countryestjasvg')
  .selectAll('*')
  .remove();
  x=32;
  shiftdata();
}
