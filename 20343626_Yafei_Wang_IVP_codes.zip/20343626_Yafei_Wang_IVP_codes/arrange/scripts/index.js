

 function showhidden(obj){
     if(obj.style.display == 'block'){
         obj.style.display = 'none';
     }
     else{
         obj.style.display ='block';
     }
 }
 var but = document.getElementById('estjabut'); 


function estja() {
    var div = document.getElementById('estja');
    showhidden(div)
    
}
function birthdayclick() {
    var div = document.getElementById('birthdayshow');
    showhidden(div)
    
}

function mbti() {
    var div = document.getElementById('detail');
    
    var div2 = document.getElementById('mbtibut');
    showhidden(div)
    showhidden(div2)
}