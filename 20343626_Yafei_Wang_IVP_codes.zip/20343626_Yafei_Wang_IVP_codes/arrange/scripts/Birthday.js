      
     var newdata =[];
     var Type =[
         'INTJ',
         'INTP',
         'ENTJ',
         'ENTP',
         'INFJ',
         'ENFP',
         'ISTJ',
         'ISFJ',
         'ESTJ',
         'ESFJ',
         'ISTP',
         'ISFP',
         'ESTP',
         'ESFP'
     ]
     var Month =[
         '1/','2/','3/','4/','5/','6/','7/','8/','9/','10','11','12'
     ]
      d3.csv('data/MBTI types and Birthdays (Responses).csv')
      .then(function(data){
        var num=0;
        for(var m=0; m<Month.length;m++){
            var num=0;
        for(var j=0;j<Type.length;j++){
        for(var i=0;i<data.length;i++)
        if(data[i].Birthday.substring(0,2) == Month[m] &&data[i].MBTIType==Type[j]){
            num++;
        }
        newdata.push({'Type':Type[j],'Mon':Month[m],'Num':num})
    }
    }
          console.log(data);
          console.log(data[0].Birthday.substring(0,2));
          console.log(newdata);
          render1(newdata);
      });

const svg1 = d3.select('#birthday');
const width1 = +svg1.attr('width');
const height1 = +svg1.attr('height');
const margin1 = {top: 60, right: 100, bottom: 60, left: 60};
const innerWidth1 = width1 - margin1.left - margin1.right;
const innerHeight1 = height1 - margin1.top - margin1.bottom;
const xValue1 = (newdata) => {return newdata.Num};
const yValue1 = (newdata) => {return newdata.Mon};
const keyValue = (newdata) => (newdata)['Type'];

      const color = {
        'INTJ':"#ff1c12",
        'INTP': "#de5991",
        'ENTJ': "#759AA0",
        'ENTP':"#E69D87",
        'INFJ':"#be3259",
        'ENFP':"#EA7E53",
        'ISTJ': "#EEDD78",
        'ISFJ': "#9359b1",
        'ESTJ': "#47c0d4",
        'ESFJ': "#F49F42",
        'ISTP': "#AA312C",
        'ISFP': "#B35E45",
        'ESTP': "#4B8E6F",
        'ESFP': "#ff8603"

      }
      const render1 = function(data){

        // Linear Scale: Data Space -> Screen Space; 
        const xScale = d3.scaleLinear()
        .domain([0, d3.max(data, xValue1)])
        .range([0, innerWidth1])
        .nice();

        // Introducing y-Scale; 
        const yScale = d3.scalePoint() // Instead of scaleBand,  use scale point; 
        .domain(data.map(yValue1))
        .range([0, innerHeight1])
        .padding(0.5);

        
        const g1 = svg1.append('g')
        .attr('transform', `translate(${margin1.left}, ${margin1.top})`)
        .attr('id', 'maingroup');

        // Do the data join (Enter)
        g1.selectAll('circle')
        .data(data)
        .enter() 
        .append('circle')  
        .attr('cy', (newdata) => { return yScale(yValue1(newdata))})
        .attr('cx', 0) 
        .attr('r', 0)
        .attr('fill', 'black')
        .transition().duration(3000)
        .attr('cx', (newdata) => {return xScale(xValue1(newdata))}) 
        .attr('r', 10)
        .attr('fill', (newdata)=> color[keyValue(newdata)])

        // Adding axes; 
        const yAxis = d3.axisLeft(yScale)
        .tickSize(-innerWidth1);
        const xAxis = d3.axisBottom(xScale)
        .tickSize(-innerHeight1);

        let yAxisGroup = g1.append('g').call(yAxis);
        
        yAxisGroup.append('text')
        .attr('y', innerHeight1 / 2)
        .attr('x', -10)
        .attr('fill', 'black').text('Month')
        .attr('id', 'Month');
        yAxisGroup.selectAll('.domain').remove(); // we can select multiple tags using comma to seperate them and we can use space to signify nesting; 
        
        let xAxisGroup = g1.append('g').call(xAxis)
        .attr('transform', `translate(${0}, ${innerHeight1})`);
        xAxisGroup.append('text')
        .attr('y', 50)
        .attr('x', innerWidth1 / 2)
        .attr('fill', 'black').text('Number')
        .attr('id', 'Number');
        xAxisGroup.selectAll('.domain').remove();
        
        let legend_color = Object.values(color);
            let legend_text = Object.keys(color);
            // draw legend
            var legend = d3.select('#maingroup').selectAll(".legend")
            .data(legend_text).join('g')
            .attr("class", "legend")
            .attr("transform", function(newdata, i) { return "translate(" + (innerWidth1 + 10) + "," + (i * 25 + 5) + ")"; });
			
            // draw legend colored rectangles
            legend.append("rect")
            .data(legend_color) 
            .attr("x", 0)
            .attr("y", 0)
            .attr("width", 30)
            .attr("height", 20)
            .style("fill", (newdata) => (newdata));
			
            // draw legend text
            legend.append("text")
            .attr("x", 40)
            .attr("y", 9)
            .attr("dy", ".5em")
            .attr("text-anchor", "start")
            .text((newdata) => (newdata)); 

        // Adding a title; 
        g1.append('text')
        .text('Birthday month personality distribution')
        .attr('y', -20)
        .attr('x', innerWidth1 / 2 - 100);
      }
      
      

